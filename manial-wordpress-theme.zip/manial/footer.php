
	
	<footer>
		
		<div id="bottom-wrap">
			<div class="bottom">
				<div class="col-bottom">
					<a class="footer-logo" href="<?php echo get_option('home'); ?>/"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" /></a>
					<h2>Search</h2>
                    <div class="search-wrap"><?php get_search_form(); ?></div>
					
					<?php dynamic_sidebar('Bottom1'); ?>
					
					
				</div>
				
				<div class="col-bottom">
					<?php dynamic_sidebar('Bottom2'); ?>
				</div>
				
				<div class="col-bottom">
					<?php dynamic_sidebar('Bottom3'); ?>
				</div>
			</div>
		</div>
		
		<div id="copyright">
			&copy; <?php echo date("Y"); echo " "; bloginfo('name'); ?>
			<a href="<?php echo esc_url( __( 'https://www.leroyne.extrazim.com/' ) ); ?>"><?php printf( __( 'Developed by Leroyne' ) ); ?></a>

		</div>
	</footer>

	<?php wp_footer(); ?>
	
	<!-- Don't forget analytics -->
	
</body>

</html>