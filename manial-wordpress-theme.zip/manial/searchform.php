<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div>
        
        <input type="search" results="5" id="s" name="s" value="" />
        
        <input type="submit" value="Search" id="searchsubmit" class="screen-reader-text"/>
    </div>
</form>