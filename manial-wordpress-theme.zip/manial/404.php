<?php get_header(); ?>

<div id="front-page">

	<h2>Error 404 - Page Not Found</h2>
	<p>The page you are looking for is not available here.</p>
</div>

<?php get_footer(); ?>