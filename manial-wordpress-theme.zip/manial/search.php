<?php get_header(); ?>

<div id="search-page">

	<?php if (have_posts()) : ?>

		<h2>Search Results</h2>

		<?php include (TEMPLATEPATH . '/inc/nav.php' ); ?>

		<?php while (have_posts()) : the_post(); ?>

			<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

				<h4><a  class="search-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

				<div class="entry">
					<a  class="img-link-to" href="<?php the_permalink(); ?>"><?php  the_post_thumbnail() ; ?></a>
					<p><?php the_excerpt(); ?></p>
					<a  class="search-link-to" href="<?php the_permalink(); ?>">...more information here >></a>
				</div>

			</div>

		<?php endwhile; ?>


	<?php else : ?>

		<h2>No posts found</h2>
		<p>The information you are looking for is not available here. Please retype or contact us for more information.</p>

	<?php endif; ?>
	
</div>



<?php get_footer(); ?>