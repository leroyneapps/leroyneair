	<aside>

		<div class="widget latest-post">

			<?php query_posts("post_per_page=1"); the_post(); ?>

			<div class="sidebar-post">
				<p class="date"><?php the_date(); ?></p>
				<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
				<p><?php the_excerpt(); ?></p>
			</div>
			
			<?php wp_reset_query(); ?>

		</div> <!-- END Latest Posts -->

		
		
		<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Widgets')) : else : ?>

		    <!-- All this stuff in here only shows up if you DON'T have any widgets active in this zone -->
		
		<?php endif; ?>

	</aside>