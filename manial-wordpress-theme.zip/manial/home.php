<?php get_header(); ?>

<div id="slideshow"><?php masterslider(4); ?></div>

<div id="front-page">


	
    <div id="home-wrap">
			<div class="home">
				
				<h4 class="features">Total air conditioning service support and Installations</h4>
				<p class="features-p">With Manial Investments, you can be rest assured that a great preventative air conditioning service solution is available. We are always
				on hand to provide expert and immediate help to improve system longevity of your cooling system.</p>
				<br><br>
				
				<div class="col-home">
                    <img src="<?php bloginfo('template_url'); ?>/images/electronic-systems.jpg" width= "100%" />
                    
				</div>
				
				<div class="col-home">
                    <img src="<?php bloginfo('template_url'); ?>/images/electronics.jpg" width= "100%" />
				
				</div>
				
				<div class="col-home">
                    <img src="<?php bloginfo('template_url'); ?>/images/air.jpg" width= "100%" />
				
				</div>
				
				
				
				<h4 class="features">Connect With Manial Investments</h4>
				<p class="features-p">For a full written quatation or to discuss your installation servicing and maintenance requirements, please contact our support team or
				fill in your details in the contact form provided <a href="./contact-us">here >></a></p>
				<p class="features-p">You can download the pdf version of our company profile <a href="<?php bloginfo('template_url'); ?>/uploads/Manial-Investments-Company-Profile.pdf">here >></a></p>
			</div>
		</div>
</div>

<?php get_footer(); ?>