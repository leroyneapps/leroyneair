
<?php $title = "About Us"; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    
            <h2>About Us</h2>
            <p>Leroyne Services is an innovative organization that is transforming the lives of individuals and companies. It was founded by a team of professionals with a passion in web development, branding, graphic design, photography and photo editing. The unique set of skills that our founder and management team bring to the table is enabling Leroyne Services to establish new industry standards.</p>
            <p>Our primary objective is to provide superior quality of services. We believe whole-heartedly that every event, or wedding, graphic design and website is unique. Because of this strongly-held belief, we take time to understand our clients’ vision for their day and their unique style.</p>
            <p>We then use that information to match clients with one of our extraordinary designers, photographers and developers. We can’t provide exceptional services without exceptional team players. Our Professional Team comprise of artist with a great distinct approach to web design, photography and other services provided.</p>
            <p>In addition to capturing amazing moments, we’re dedicated to providing incomparable service. Paying much into detail, our clients focus more on enjoying the happiest moments of their lives. Leroyne Services also believe in transparency - because there is already enough guess-work in planning an event.</p>
            <p>You’ll find our pricing and package information readily available on our website. Additionally, all of our photography packages include rights to your digital negatives, so that you’ll be able to share your memories, or create your own album.</p>
 
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>