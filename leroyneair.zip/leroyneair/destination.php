
<?php $title = "Destination"; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    
 <div class="desti-articles-gray clear">
                    
                    <div class="img"><img src="assets/images/harare.jpg"></div>
					
					<div class="articles">
                    <h3>Harare</h3>
                    <p>Harare officially called Salisbury until 1982[4]) is the capital and most populous city of Zimbabwe. Situated in the north-east of the country in the heart of historic Mashonaland, the city has an estimated population of 1,606,000 (2009),[5] with 2,800,000 in its metropolitan area (2006). Administratively, Harare is a metropolitan province, which also incorporates Chitungwiza town and Epworth.[6] It is situated at an elevation of 1,483 metres (4,865 feet) above sea level and its climate falls into the subtropical highland category.</p>
					</div>

                </div>
                
                <div class="desti-articles-white clear">
                    
                    <div class="img"><img src="assets/images/bulawayo.jpg"></div>
					
					<div class="articles">
                    <h3>Bulawayo</h3>
                    <p>Bulawayo is the second-largest city in Zimbabwe after the capital Harare, with, as of the 2012 census, a population of 653,337.[2] It is located in Matabeleland, 439 km (273 mi) southwest of Harare, and is now treated as a separate provincial area from Matabeleland. The capital of Matabeleland North is now Lupane, as Bulawayo is a stand-alone province.</p>
					</div>
                </div>
                
                <div class="desti-articles-gray clear">
                    <div class="img"><img src="assets/images/victoriafalls.jpg"></div>
					
					<div class="articles">
                    <h3>Victoria Falls</h3>
                    <p>Harare officially called Salisbury until 1982[4]) is the capital and most populous city of Zimbabwe. Situated in the north-east of the country in the heart of historic Mashonaland, the city has an estimated population of 1,606,000 (2009),[5] with 2,800,000 in its metropolitan area (2006). Administratively, Harare is a metropolitan province, which also incorporates Chitungwiza town and Epworth.[6] It is situated at an elevation of 1,483 metres (4,865 feet) above sea level and its climate falls into the subtropical highland category.</p>
					</div>

                </div>
                
                <div class="desti-articles-white clear">
                    
                    <div class="img"><img src="assets/images/kariba.jpg"></div>
					
					<div class="articles">
                    <h3>Kariba</h3>
                    <p>Bulawayo is the second-largest city in Zimbabwe after the capital Harare, with, as of the 2012 census, a population of 653,337.[2] It is located in Matabeleland, 439 km (273 mi) southwest of Harare, and is now treated as a separate provincial area from Matabeleland. The capital of Matabeleland North is now Lupane, as Bulawayo is a stand-alone province.</p>
					</div>
				</div>
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>