<!-- The footer section of the website -------------------------------------------------------------------------------------------->
        <footer class="clear">
            <div class="wrap-footer">
				<a href="#top" class="backtotop"><img src="assets/images/backtotop.svg"></a>
                <p>&copy 2016. Leroyne Airline . All Rights Reserved</p>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="booking.php">Booking Online</a></li>
                    <li><a href="destination.php">Destination</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                </ul>
            </div>
			
			<div class="wra-footer">
				<p class="developer">Website Developed by <a href="http://leroyne.extrazim.com">Leroyne Services</a></p>
			</div>
        </footer>
            
        <script src="assets/js/main.js"></script>    
        </body>
    </html>