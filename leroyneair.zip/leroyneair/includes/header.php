
<?php

    include("connect.php");
    include("functions.php");
?>

<!DOCTYPE>
    <html>
        <head>
            <title><?php echo $title; ?> | Welcome to Leroyne Airways</title>
            <link rel="stylesheet" type="text/css" href="assets/css/main.css" >
            <link rel="stylesheet" type="text/css" href="assets/css/responsive.css" >
        </head>
        
        <body>
            
            <!---------------------------------------------
            The header of the Page
            ------------------------------------------------>
            <div class="top-wrap" class="clear">
            <header id="top-section" class="clear">
                <ul>
                    <li>Follow Us:
                        <a href="http://www.facebook.com"><img src="assets/images/fb.svg" class="fb"></a>
                        <a href="http://www.twitter.com"><img src="assets/images/twitter.svg" class="twitter"></a>
                        <a href="http://plus.google.com"><img src="assets/images/gplus.svg" class="gplus"></a>
                    </li>
                    <li><strong>Today's Date:</strong> <?php echo date("D d M Y"); ?></li>
                    <li>
                        <a href="admin/index.php" class="admin-button">Admin Login</a>
                    </li>
                </ul>
                
            </header>
            
            
            <header id="header-section" class="clear">
                <div class="logo"><a href="index.php"><img src="assets/images/logo.png"></a></div>
            </header>
            </div>
            
            <!---------------------------------------------
            The Navigation Area of the Page
            ------------------------------------------------>
            
            <nav class="clear">
                <ul class="clear">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="destination.php">Destinations</a></li>
                    <li><a href="booking.php">Booking Online</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                </ul>
            </nav>