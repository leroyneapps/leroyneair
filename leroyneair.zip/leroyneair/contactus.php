
<?php $title = "Contact Us"; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    
        <div class="contact-wrap">
                                
                                <h2>Contact Us</h2>
                                <p>Adress: 16257 Damofalls, Ruwa</p>
                                <p>Mobile: +263-773817112</p>
                                <p>Email:<a href="mailto:leroynephoto@gmail.com"> leroynephoto@gmail.com</a></p>
                                
                                <p>Please fill in your details below and we will get back to you shortly.</p>
                                
                                <form method="post">
                                    <?php contact(); ?>
                                    <ul>
                                        <li><label>Name</label><br>
                                            <input type="text" name="name" placeholder="Name" required=></li>
                                        <li><label>Surname</label><br>
                                            <input type="text" name="surname" placeholder="Surname" required=></li>
                                        <li><label>Mobile Number</label><br>
                                            <input type="text" name="mobile" placeholder="mobile" required=></li>
                                        <li><label>Email</label><br>
                                            <input type="text" name="email" placeholder="Email" required=></li>
                                        <li><label>Subject</label><br>
                                            <input type="text" name="subject" placeholder="Subject" required=></li>
                                        <li><label>Message</label><br>
                                            <textarea name="message" required=></textarea></li>
                                        <li><button type="submit" name="send">Send</button></li>
                                    </ul>
                                </form>
                            </div>
 
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>