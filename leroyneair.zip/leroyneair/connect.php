<?php
    $DBHOST = "localhost";
    $DBUSER = "root";
    $DBPASS = "";
    $DBNAME = "leroyneDB";
    
    $connect = new mysqli ($DBHOST, $DBUSER, $DBPASS, $DBNAME);
    
    if($connect == false){
        die("Error, database error occured. please check your settings. ");
    }
    
?>