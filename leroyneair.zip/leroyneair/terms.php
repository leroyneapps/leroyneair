
<?php $title = "Terms and Conditions"; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    <h1>Terms and Conditions</h1>
	<br>
	<h3>Air Reservations and Booking Conditions</h3>
	<p>Reservations may be made in person or on the website without obligation. Reservations made with no payment processed in 24 hours after booking will be cancelled. Reservations made within 24 hours of departure should be ticketed simultaneously.</p>
	<h3>Passports and National Identification.</h3>
	<p>Passengers must be in possession of a full valid passport, national ID, student ID for local domestic flights. It is the responsibility of passengers to ensure they satisfy all applicable requirements in respect of passport and identity matters. The airline will not be held liable if you fail to ensure this as you will be denied boarding.</p>
	<h3>Methods of Payment</h3>
	<p>Cash and credit cards are acceptable as form of payment. Airline accepts VISA / MASTERCARD / ECOCASH. The cardholder has to sign the charge form at time of purchase.</p>
	<h3>General Ticketing Conditions</h3>
	<p>For cancellations before departure, an amount equal to the fare paid less cancellation fees, depending on the class of travel, will be refunded. There is no refund after departure on special fares when one segment has been used.</p>
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>



    

