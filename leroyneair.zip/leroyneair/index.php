
<?php $title = "Home "; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>


            <!---------------------------------------------
            The Slideshow Area of the Page
            ------------------------------------------------>
            
            <div id="slide-wrap" class="clear">
                    <div class="slide-wrap"><img src="assets/images/flightslide.png"></div>
                    <h1>Welcome to Leroyne Airline</h1>
                    
                    <p>To make a booking with our airline please click the button below and fill in your details. The prices listed are past searches done by real customers in the last 24 hours for specific travel dates. Fares are subject to change.</p>
                    <a href="booking.php">Online Booking Here >></a>

            </div>
            
            
            <!---------------------------------------------
            The Front Features Area of the Page
            ------------------------------------------------>
            <section id="front-articles" class="clear">
                        
                        <div class="article1">
                            <div class="wrap-img"><img src="assets/images/harare.jpg"></div>
                            <h3>Visit Harare today</h3>
                            <p>Buy your ticket now and enjoy the experience to the Capital City of Harare</p>
                        </div>
                        
                        <div class="article1">
                            <div class="wrap-img"><img src="assets/images/bulawayo.jpg"></div>
                            <h3>Business in Bulawayo</h3>
                            <p>Score great deals in Bulawayo with low fares from us.</p>
                        </div>
                        
                        <div class="article1">
                            <div class="wrap-img"><img src="assets/images/victoriafalls.jpg"></div>
                            <h3>Holiday in Vic-Falls</h3>
                            <p>Business hotel designed to meet the needs of today's business travelers. </p>
                        </div>
                        
                        <div class="article1">
                            <div class="wrap-img"><img src="assets/images/kariba.jpg"></div>
                            <h3>Enjoy your flight to Kariba</h3>
                            <p>Leroyne Airline allows you to find the cheapest flights to Kariba.</p>
                        </div>
                        
                        
            </section>
            
            
            <section id="front-articles" class="clear">
                
                <div class="col1">
                    <h2>About Us</h2>
                    <img src="assets/images/aboutus.jpg">
                    <p>Leroyne Services is an innovative organization that is transforming the lives of individuals and companies. It was founded by a team of professionals with a passion in web development, branding, graphic design, photography and photo editing</p>
                    <a href="aboutus.php">...click here >></a>
                </div>
                
                <div class="col2">
                    
                        <fieldset>
                        <legend>Flight Schedule</legend>
                            <table class="timetable-schedule">
                            <thead>
                                
                                <p>All departure and arrival time are shown in local time. Schedule is for reference only and subject to change without prior notice.</p>
                            </thead>
                            <tbody>
                                <tr class="tr-head">
                                    <td class="td-head">Origin</td>
                                    <td>Time</td>
                                    <td class="td-head">Destination</td>
                                    <td>Time</td>
                                </tr>
                                <tr>
                                    <td>Harare</td>
                                    <td>09:00</td>
                                    <td>Bulawayo</td>
                                    <td>10:00</td>
                                </tr>
                                
                                 <tr>
                                    <td>Bulawayo</td>
                                    <td>11:00</td>
                                    <td>Victoria Falls</td>
                                    <td>12:00</td>
                                </tr>
                                 
                                  <tr>
                                    <td>Victoria Falls</td>
                                    <td>13:00</td>
                                    <td>Kariba</td>
                                    <td>14:00</td>
                                </tr>
                                  
                                   <tr>
                                    <td>Kariba</td>
                                    <td>15:00</td>
                                    <td>Harare</td>
                                    <td>16:00</td>
                                
                            </tbody>
                        </table>
                        </fieldset>
                    
                        <fieldset>
                        <legend>Check Booking</legend>
                        <p>If you have already booked a flight with us you can check if your booking is accepted below. Enter the details required to check.</p>
                        <form method="post" action="check.php">
                            <label>Enter National ID</label>
                            <input type="text" name="nationalID" placeholder="00-0000000E00" required=>
                            <label>Enter surname</label>
                            <input type="text" name="surname" placeholder="Enter your surname" required=>
                            <button type="submit" name="check">Check</button>
                        </form>
                        </fieldset>
                </div>
                </div>
                
                
                
            </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>