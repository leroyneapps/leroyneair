
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Add New User</h2>
                
                <div class="overflow">
                 <form method="post">
                  <?php createuser(); ?>
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Enter username">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter password">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="Enter email"><br>
                    <button type="submit" name="submit">Submit</button>
                    </form>
                </div>
 
<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>