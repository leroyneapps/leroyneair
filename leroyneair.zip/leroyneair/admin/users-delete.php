
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>


<?php 
    if(isset($_GET['id'])){
     
    $id = $_GET['id']; 
    $sql = "DELETE FROM users WHERE id='$id' ";
    $result = $connect->query($sql);
    header("Location: users-view.php");
    }
?>
                     
                    
                

