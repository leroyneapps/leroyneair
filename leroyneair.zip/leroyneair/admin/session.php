<?php

    include("../connect.php");
    
    session_start();
    if(!isset($_SESSION["username"]) AND $_SESSION[""]){
        header("Location: index.php");
    } else {
        //header("Location: dashboard.php");
        
    }

?>