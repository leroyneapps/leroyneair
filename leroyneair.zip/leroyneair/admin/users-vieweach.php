
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>User Details</h2>
                
                <div class="overflow">
                <?php
                
                 if(isset($_GET['id'])){
                  
                 $id = $_GET['id']; 
                 $sql = "SELECT * FROM users WHERE id='$id' ";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>

                           <p><label>Username </label><?php echo $row["username"]; ?></p>
 
                           <p><label>Password </label><?php echo $row["password"]; ?></p>
                          
                           <p><label>Email </label><?php echo $row["email"]; ?></p>
                           
                           <p><label>Date Created </label><?php echo $row["date_created"]; ?></p>

                <?php
                
                  }
                 }
                 ?>
                    </div>
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>