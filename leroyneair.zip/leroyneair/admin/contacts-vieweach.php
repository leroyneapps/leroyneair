
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Read Message</h2>
                
                <div class="overflow">
                <?php
                
                 if(isset($_GET['id'])){
                  
                 $id = $_GET['id']; 
                 $sql = "SELECT * FROM contacts WHERE id='$id' ";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>

                           <p><label>Name </label><?php echo $row["name"] . " " .$row["surname"] ; ?> | <label>Date Received </label><?php echo $row["date"]; ?></p>
                           
                           <p><label>Mobile </label><?php echo $row["mobile"]; ?> | <label>Email </label><?php echo $row["email"]; ?></p>
                      
                           <p><label>Subject </label><?php echo $row["subject"]; ?></p>
                           
                           <p class="wrap-message"><label>Message </label><br><br><?php echo $row["message"]; ?></p>
                           

                <?php
                
                  }
                 }
                 ?>
                    </div>
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>