
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>All Bookings Viewed Listed</h2>
                
                <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>ID</td><td>Tickets-N0.</td><td>Payment</td><td>Firstname</td><td>Surname</td>
                            </tr>
                        </thead>
                        <tbody>
                <?php
                
                 $sql = "SELECT * FROM bookings";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>
                    
                            <tr>
                             <td><?php echo $row["id"]; ?></td>
                             <td><?php echo $row["ticketNO"]; ?></td>
                             <td><?php echo $row["payment"]; ?></td>
                             <td><?php echo $row["firstname"]; ?></td>
                             <td><?php echo $row["surname"]; ?></td>
                             <td><a href="bookings-vieweach.php?id=<?php echo $row['id']; ?>">View</a></td>
                             <td><a href="bookings-edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>
                             <td><a href="bookings-delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>
                            </tr>

                   
                <?php
                
                  }
                 
                 ?>
                     </tbody>
                    </table>
                    </div>
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>