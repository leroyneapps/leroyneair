<?php
    
    function countusers(){
        global $connect;
        
        $sql = "SELECT * FROM users";
        $result = $connect->query($sql);
        
        $countusers = mysqli_num_rows($result);
        return($countusers);
    }
    
    function countbookings(){
        global $connect;
        
        $sql = "SELECT * FROM bookings";
        $result = $connect->query($sql);
        
        $countbookings = mysqli_num_rows($result);
        return($countbookings);
    }
    
    function countmessages(){
        global $connect;
        
        $sql = "SELECT * FROM contacts";
        $result = $connect->query($sql);
        
        $countmessages = mysqli_num_rows($result);
        return($countmessages);
    }
    
    
    function createuser(){
        global $connect;
        
        if(isset($_POST['submit'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        
        $insert = "INSERT INTO users (id, username, password, email, date_created) ";
        $insert .= "VALUES('', '$username', '$password', '$email', now())";
        
        $query = $connect->query($insert);
        header("Location: users-view.php");
        }
    }
    
    

?>