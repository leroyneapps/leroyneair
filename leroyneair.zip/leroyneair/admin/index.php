<?php
    include("../connect.php"); 
    include("functions.php");
    
    session_start();
    if(isset($_SESSION["username"])){
        header("Location: dashboard.php");
    }
    
    
    if(isset($_POST['submit'])){
            
            $username = $_POST["username"];
            $password = $_POST["password"];
            
            $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
            $result = $connect->query($sql);
            
                while($row = $result->fetch_assoc()) {
                    $id = $row['id'];
                    $user = $row['username'];
                    $pass = $row['password'];
                    
                    if($username === $user AND $password === $pass ){
                        header("Location: dashboard.php");
                        $_SESSION['username'] = $user;
                        $_SESSION['id'] = $id;
                    } 
                }
    }
    
    ?>
    
<!DOCTYPE html>
    <html>
        <head>
            <title>Amdin Login Panel</title>
            <link rel="stylesheet" type="text/css" href="assets/css/main.css">
        </head>
        
        <body>
            <section id="wrap-logo">
                <h2>Admin Login Panel</h2>
                <form method="post">
                    <label for="username">Username</label>
                    <input type="text" name="username" placeholder="username"><br>
                    <label for="password">Password</label>
                    <input type="password" name="password" placeholder="password"><br>
                    <button type="submit" name="submit">Login</button>
                    <button type="reset" name="reset">Reset</button>
                </form>
                <a href="../index.php" class="home-button">Home Website</a>
            </section>
        </body>
    </html>