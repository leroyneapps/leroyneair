
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Edit Your Profile</h2>
                <?php
                        
                    if(isset($_GET['id'])){
                    
                    $id = $_GET['id'];
                        
                    $sql = "SELECT * FROM users WHERE id='$id'";
                    $result = $connect->query($sql);
                        
                        while($row = $result->fetch_assoc()) {
                            $user = $row["username"];
                            $password = $row["password"];
                            $email = $row["email"];
                
                ?>
                
                <fieldset>
                    <legend>Edit Your Profile</legend>
                <form method="post">
                    
                    <?php
                     if(isset($_POST['submit'])){
            
                          $user = $_SESSION["username"];
                          $username = $_POST["username"];
                          $password = $_POST["password"];
                          $email = $_POST["email"];
                          
                          $sql = "UPDATE users SET username='$username', password='$password', email='$email' WHERE id = '$id'";
                          if ($connect->query($sql) === TRUE) {
                          echo "Record updated successfully<br>";
              
                          } else {
                          echo "Error updating record: " . $connect->error;
                          }
                      }
                    
                    ?>
                    <label>Username</label><br>
                    <input type="text" name="username" value="<?php echo $user; ?>" ><br>
                    <label>Password</label><br>
                    <input type="text" name="password" value="<?php echo $password; ?>" ><br>
                    <label>Email</label><br>
                    <input type="email" name="email" value="<?php echo $email; ?>" ><br>
                    <button type="submit" name="submit">Update</button>
                    
                </form>
                </fieldset>
                </div>
                
              <?php
              
                      }
                    }
                
                ?>
                

<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>