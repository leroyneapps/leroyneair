<header class="clear">
                    <a href="dashboard.php" class="logo">Dashboard Home</a>
                    <span class="position-right"><strong>Loggedin User: </strong><?php echo $_SESSION["username"]; ?> <a href="logout.php">Logout</a></span>
</header>