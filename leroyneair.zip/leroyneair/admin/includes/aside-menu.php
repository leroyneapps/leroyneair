
<div id="col1">
    <ul>
    <li><a href="../">Website Home</a></li>
     <li><a href="dashboard.php">Home</a></li>
     <li><a href="bookings-view.php">View Bookings</a></li>
     <li><a href="contacts-view.php">View Contacts</a></li>
     <li><a href="users-view.php">Users</a></li>
     <li><a href="users-add.php">Add New User</a></li>
     <li><a href="edit-profile.php?id=<?php echo $_SESSION['id']; ?>">Edit Profile</a></li>
    </ul> 
 </div>