<?php
    include("session.php");
    include("functions.php");
?>

<!DOCTYPE>
    <html>
        <head>
            <title>Welcome to the Admin CPanel Dashboard</title>
            <link rel="stylesheet" type="text/css" href="assets/css/main.css" >
        </head>
        
        <body>