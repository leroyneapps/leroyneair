
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
                <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
                <div id="col2">
                    
                    
                    <fieldset>
                        <legend>Number of Bookings</legend>
                        <p>Total Number of Bookings</p>
                        <h5 class="total"><?php echo "Total: " . countbookings(); ?></h5>
                    </fieldset>
                    
                    <fieldset>
                        <legend>Number of Contact Messages</legend>
                        <p>Total Number of Contacts</p>
                        <h5 class="total"><?php echo "Total: " . countmessages(); ?></h5>
                        
                        <a href="contacts-view.php">View</a>
                    </fieldset>
                    
                    <fieldset>
                        <legend>Number of Users</legend>
                        <p>Total Number of Users</p>
                        <h5 class="total"><?php echo "Total: " . countusers(); ?></h5>
                        
                        <a href="users-view.php">View</a> | <a href="users-add.php">Add</a> 
                    </fieldset>
                </div>
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>