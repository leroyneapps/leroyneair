
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Booking Stored</h2>
                
                <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>Description</td><td>User Details</td>
                            </tr>
                        </thead>
                        <tbody>
                <?php
                
                 if(isset($_GET['id'])){
                  
                 $id = $_GET['id']; 
                 $sql = "SELECT * FROM bookings WHERE id='$id' ";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>
                    
                            <tr>
                             <td>User ID</td>
                             <td><?php echo $row["id"]; ?></td>
                            </tr>
                            <tr>
                             <td>Payment</td>
                             <td><?php echo $row["payment"]; ?></td>
                            </tr>
                            <tr>
                            <tr>
                             <td>Ticket No.</td>
                             <td><?php echo $row["ticketNO"]; ?></td>
                            </tr>
                            <tr>
                             <td>First Name</td>
                             <td><?php echo $row["firstname"]; ?></td>
                            <tr>
                             <td>Surname</td>
                             <td><?php echo $row["surname"]; ?></td>
                            </tr>
                            <tr>
                             <td>Sex</td>
                             <td><?php echo $row["sex"]; ?></td>
                            </tr>
                            <tr>
                             <td>Date of Birth</td>
                             <td><?php echo $row["dateofbirth"]; ?></td>
                            </tr>
                            <tr>
                             <td>National ID</td>
                             <td><?php echo $row["nationalID"]; ?></td>
                            </tr>
                            <tr>
                             <td>Mobile</td>
                             <td><?php echo $row["mobile"]; ?></td>
                            </tr>
                            <tr>
                             <td>Email</td>
                             <td><?php echo $row["email"]; ?></td>
                            </tr>
                            <tr>
                             <td>Home Address</td>
                             <td><?php echo $row["home_address"]; ?></td>
                            </tr>
                            <tr>
                             <td>Fly From</td>
                             <td><?php echo $row["fly_from"]; ?></td>
                            </tr>
                            <tr>
                             <td>Fly To</td>
                             <td><?php echo $row["fly_to"]; ?></td>
                            </tr>
                            <tr>
                             <td>Date of Travel</td>
                             <td><?php echo $row["day"]; ?> <?php echo $row["dat"]; ?> <?php echo $row["month"]; ?> <?php echo $row["year"]; ?></td>
                            </tr>
                            <tr>
                             <td>Date Submitted</td>
                             <td><?php echo $row["date"]; ?></td>
                            </tr>

                   
                <?php
                
                  }
                 }
                 ?>
                     </tbody>
                    </table>
                    </div>
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>