
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>All Users</h2>
                <?php
                   $sql = "SELECT * FROM users";
                    $result = $connect->query($sql);
                    
                    if ($result->num_rows > 0) {
                        
                        
                ?>
                    <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>Username</td><td>Email</td><td>Date Created</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        
                        while($row = $result->fetch_assoc()) {
                         
                         ?>
                        <tr>
                         <td><?php echo $row["username"]; ?></td>
                         <td><?php echo $row["email"]; ?></td>
                         <td><?php echo $row["date_created"]; ?></td>
                         <td><a href="users-vieweach.php?id=<?php echo $row['id']; ?>">View</a></td>
                         <td><a href="users-edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>
                         <td><a href="users-delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>
                        </tr>
                     
                     <?php   }
                    } 
                        
                        ?>
                        </tbody>
                    </table>
                    </div>
                
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>