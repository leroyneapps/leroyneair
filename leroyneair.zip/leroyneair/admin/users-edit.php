
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Edit User</h2>
                
                <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>Description</td><td>User Details</td>
                            </tr>
                        </thead>
                        <tbody>
                <?php
                
                 if(isset($_GET['id'])){
                  
                 $id = $_GET['id']; 
                 $sql = "SELECT * FROM users WHERE id='$id' ";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>
                    
                    <form method="post">
                            <tr>
                             <td>User ID</td>
                             <td><input type="text" placeholder="<?php echo $row["id"]; ?>" readonly= ></td>
                            </tr>
                            
                            <tr>
                             <td>Username</td>
                             <td><input type="text" name="username" value="<?php echo $row["username"]; ?>"></td>
                            <tr>
                             <td>Password</td>
                             <td><input type="text" name="password" value="<?php echo $row["password"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Email</td>
                             <td><input type="text" name="email" value="<?php echo $row["email"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Date Created</td>
                             <td><input type="text" name="date_created" value="<?php echo $row["date_created"]; ?>"></td>
                            </tr>
                            
                            
                            <tr>
                             <td></td>
                             <td><button type="submit" name="submit">Update</button></td>
                            </tr>
                    </form>    

                   
                <?php
                
                  }
                 }
                 ?>
                     </tbody>
                    </table>
                    </div>
                </div>
                
                <?php
                 if(isset($_POST['submit'])){
            
                  $username = $_POST["username"];
                  $password = $_POST["password"];
                  $email = $_POST["email"];
                  
                  
                  $insert = " UPDATE users SET ";
                  $insert .= "username='$username', password='$password', email='$email' WHERE id='$id' ";
                  $query = $connect->query($insert);
                  
                  header("Location: users-view.php");
                  }
                ?>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>