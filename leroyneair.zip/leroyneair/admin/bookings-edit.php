
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Edit Booking</h2>
                
                <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>Description</td><td>User Details</td>
                            </tr>
                        </thead>
                        <tbody>
                <?php
                
                 if(isset($_GET['id'])){
                  
                 $id = $_GET['id']; 
                 $sql = "SELECT * FROM bookings WHERE id='$id' ";
                 $result = $connect->query($sql);
                     
                     while($row = $result->fetch_assoc()) {
                     
                    ?>
                    
                    <form method="post">
                            <tr>
                             <td>User ID</td>
                             <td><input type="text" placeholder="<?php echo $row["id"]; ?>" readonly= ></td>
                            </tr>
                            <tr>
                             <td>Payment</td>
                             <td>
                              <select name="payment">
                               <option value="$50.00">$50.00</option>
                               <option value="$60.00">$60.00</option>
                               <option value="$80.00">$80.00</option>
                               <option value="$100.00">$100.00</option>
                               <option value="$120.00">$120.00</option>
                               <option value="$150.00">$150.00</option>
                              </select>
                            </tr>
                            <tr>
                            <tr>
                             <td>Ticket No.</td>
                             <td><input type="text" placeholder="<?php echo $row["ticketNO"]; ?>" readonly= ></td>
                            </tr>
                            <tr>
                             <td>First Name</td>
                             <td><input type="text" name="firstname" value="<?php echo $row["firstname"]; ?>"></td>
                            <tr>
                             <td>Surname</td>
                             <td><input type="text" name="surname" value="<?php echo $row["surname"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Sex</td>
                             <td>
                              <select name="sex">
                               <option value="Male">Male</option>
                               <option value="Female">Female</option>
                               </select>
                             </td>
                            </tr>
                            <tr>
                             <td>Date of Birth</td>
                             <td><input type="text" name="dateofbirth" value="<?php echo $row["dateofbirth"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>National ID</td>
                             <td><input type="text" name="nationalID" value="<?php echo $row["nationalID"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Mobile</td>
                             <td><input type="text" name="mobile" value="<?php echo $row["mobile"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Email</td>
                             <td><input type="text" name="email" value="<?php echo $row["email"]; ?>"></td>
                            </tr>
                            <tr>
                             <td>Home Address</td>
                             <td><textarea name="home_address"><?php echo $row["home_address"]; ?></textarea></td>
                            </tr>
                            <tr>
                             <td>Fly From</td>
                             <td>
                              <select name="fly_from">
                              <option value="Harare">Harare</option>
                              <option value="Bulawayo">Bulawayo</option>
                              <option value="Vicfalls">Vic Falls</option>
                              <option value="Kariba">kariba</option>
                                     </select>
                             </td>
                            </tr>
                            <tr>
                             <td>Fly To</td>
                             <td>
                              <select name="fly_to">
                               <option value="Harare">Harare</option>
                               <option value="Bulawayo">Bulawayo</option>
                               <option value="Vicfalls">Vic Falls</option>
                               <option value="Kariba">kariba</option>
                                      </select>
                             </td>
                            </tr>
                            <tr>
                             <td>Date of Travel</td>
                             <td>
                              <select name="day">
                              <option value="Sunday">Sunday</option>
                              <option value="Monday">Monday</option>
                              <option value="Tuesday">Tuesday</option>
                              <option value="Wednesday">Wednesday</option>
                              <option value="Thursday">Thursday</option>
                              <option value="Friday">Friday</option>
                              <option value="Saturday">Saturday</option>
                              </select>
                              
                              <select name="dat">
                              <option value="01">01</option>
                              <option value="02">02</option>
                              <option value="03">03</option>
                              <option value="04">04</option>
                              <option value="05">06</option>
                              <option value="07">07</option>
                              <option value="08">08</option>
                              <option value="09">09</option>
                              <option value="10">10</option>
                              <option value="11">11</option>
                              <option value="12">12</option>
                              <option value="13">13</option>
                              <option value="14">14</option>
                              <option value="15">15</option>
                              <option value="16">16</option>
                              <option value="17">17</option>
                              <option value="18">18</option>
                              <option value="19">19</option>
                              <option value="20">20</option>
                              <option value="21">21</option>
                              <option value="22">22</option>
                              <option value="23">23</option>
                              <option value="24">24</option>
                              <option value="25">25</option>
                              <option value="26">26</option>
                              <option value="27">27</option>
                              <option value="28">28</option>
                              <option value="29">29</option>
                              <option value="30">30</option>
                              <option value="31">31</option>
                              </select>
                              
                              <select name="month">
                              <option value="January">January</option>
                              <option value="February">February</option>
                              <option value="March">March</option>
                              <option value="April">April</option>
                              <option value="May">May</option>
                              <option value="June">June</option>
                              <option value="July">July</option>
                              <option value="August">August</option>
                              <option value="September">September</option>
                              <option value="October">October</option>
                              <option value="November">November</option>
                              <option value="December">December</option>
                              </select>
                              
                              <select name="year">
                              <option value="2017">2017</option>
                              <option value="2018">2018</option>
                              </select>
                             </td>
                            </tr>
                            <tr>
                             <td></td>
                             <td><button type="submit" name="submit">Update</button></td>
                            </tr>
                    </form>    

                   
                <?php
                
                  }
                 }
                 ?>
                     </tbody>
                    </table>
                    </div>
                </div>
                
                <?php
                 if(isset($_POST['submit'])){
            
                  $firstname = $_POST["firstname"];
                  $surname = $_POST["surname"];
                  $sex = $_POST["sex"];
                  $dateofbirth = $_POST["dateofbirth"];
                  $nationalID = $_POST["nationalID"];
                  $mobile = $_POST["mobile"];
                  $email = $_POST["email"];
                  $home_address = $_POST["home_address"];
                  $fly_from = $_POST["fly_from"];
                  $fly_to = $_POST["fly_to"];
                  $day = $_POST["day"];
                  $dat = $_POST["dat"];
                  $month = $_POST["month"];
                  $year = $_POST["year"];
                  $payment = $_POST["payment"];
                  
                  
                  $insert = " UPDATE bookings SET ";
                  $insert .= "payment='$payment', firstname='$firstname', surname='$surname', sex='$sex', dateofbirth='$dateofbirth', nationalID='$nationalID', ";
                  $insert .= "mobile='$mobile', email='$email', home_address='$home_address', fly_from='$fly_from', ";
                  $insert .= "fly_to='$fly_to', day='$day', dat='$dat', month='$month', year='$year' WHERE id='$id' ";
                  $query = $connect->query($insert);
                  
                  
                   
                  
                  }
                ?>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>