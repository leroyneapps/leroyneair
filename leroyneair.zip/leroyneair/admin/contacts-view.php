
<!-- Include the header file------------->
<?php include("includes/header.php"); ?>

<!------------------------------------>
            
            <section id="wrapper" class="clear">
             <?php include("includes/top-menu.php"); ?>
                
                <div class="content clear">
                <?php include("includes/aside-menu.php"); ?>
                
<!-- The content area for the admin ---->
                <div id="col2">
                    
                <h2>Inbox Contacts</h2>
                
                <?php
                 $sql = "SELECT * FROM contacts";
                 $result = $connect->query($sql);
                 
                 if ($result->num_rows > 0) {
                ?>
                    <div class="overflow">
                    <table>
                        <thead>
                            <tr>
                                <td>Firstname</td><td>Posted-Date</td>
                            </tr>
                        </thead>
                        <tbody>
                  <?php
                  while($row = $result->fetch_assoc()) {
                   
                   ?>
                     
                     <tr>
                      <td><?php echo $row["name"]; ?></td>
                      <td><?php echo $row["date"]; ?></td>
                      <td><a href="contacts-vieweach.php?id=<?php echo $row['id']; ?>">Read</a></td>
                      <td><a href="contacts-delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>
                     </tr>
                 
                 <?php
                 }
                 } 
                           
                  ?>      
                        </tbody>
                    </table>
                    </div>
                
                </div>
                


<!-- Include the footer file------------->
<?php include("includes/footer.php"); ?>

<!------------------------------------>