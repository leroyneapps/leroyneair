
<?php $title = "Booking Online"; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    <h1>Air Ticket Reservation</h1>
    <br>
    
    <form method="post" class="booking">
       <?php booking(); ?>
       <fieldset>
        <legend>Passenger Information</legend>
		  <p>Fill in your details in the space provided below. The information you enter here is required for your reservation to be processed. Read our terms and conditions before you make your booking with our airline. <a href="terms.php" target="_blank">Terms and Condition</a></p>
        <p><strong>Please Note: </strong>After making booking, please visit our accounts office to process your payment. The identification details are required during the journey. One of the passenger booked on the ticket should have any of the identity cards ( Passport / National ID / Driving License / School Student ID) during the journey in original. </p>

	<label>First Name</label><input type="text" name="firstname" placeholder="First Name" required= > 
	<label>Surname</label><input type="text" name="surname" placeholder="Surname" required= > 
	<label>Sex</label><select name="sex">
	<option value="Male">Male</option>
	<option value="Female">Female</option>
	</select>
	

	<br>
	<label>Date of Birth</label><input type="text" name="dateofbirth" placeholder="1900-04-13" required= > 
	<label>NationalID</label><input type="text" name="nationalID" placeholder="63-0000000E00" required=> 
	<label>Mobile Number</label><input type="text" name="mobile" placeholder="+263773000000" required=> 
	
	<br>
	<label>Email Adress</label><input type="email" name="email" placeholder="user@emailaddress.com" required=> 
	<label>Home Address</label><textarea name="home_address" placeholder="Home Adress" required=></textarea>



    </fieldset>
       
    <fieldset>
        <legend>Travel Booking Information</legend>
        <label>Boarding From*</label><select name="fly_from">
	<option value="Harare">Harare</option>
	<option value="Bulawayo">Bulawayo</option>
	<option value="Vicfalls">Vic Falls</option>
	<option value="Kariba">kariba</option>
        </select>
        
        <label>Destination*</label><select name="fly_to">
	<option value="Vicfalls">Vic Falls</option>
	<option value="Kariba">kariba</option>
	<option value="Harare">Harare</option>
	<option value="Bulawayo">Bulawayo</option>
        </select>
        <br>
        
	<select name="day">
	<option value="Sunday">Sunday</option>
	<option value="Monday">Monday</option>
	<option value="Tuesday">Tuesday</option>
	<option value="Wednesday">Wednesday</option>
	<option value="Thursday">Thursday</option>
	<option value="Friday">Friday</option>
	<option value="Saturday">Saturday</option>
	</select>
	
	<select name="dat">
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05">06</option>
	<option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
	</select>
	
	<select name="month">
	<option value="January">January</option>
	<option value="February">February</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
	</select>
	
	<label>Date of Travel</label><select name="year">
	<option value="2017">2017</option>
	<option value="2018">2018</option>
	</select>
	
    </fieldset>
    
    <fieldset>
        <legend>Terms of Service</legend>
        <p>Please visit our page <a href="terms.php" target="_blank">Terms and Conditions</a> and read them carefully. By click of the button below, you accept to our Terms and Conditions. </p>
	<input type="checkbox" name="accept_terms" value="accept_terms" required= ><label>* I accept the Terms and Conditions</label>
	<br>

    </fieldset>
    
    
    <button type="submit" name="submit" class="submit">Send Now</button>
    <button type="reset" name="reset" value="reset" class="submit">Clear Now</button>
    
    </form>
			
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>