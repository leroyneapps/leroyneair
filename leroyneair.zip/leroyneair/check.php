
<?php $title = "Check your booking."; ?>

<!-- Includes the header section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/header.php"); ?>
            
    <!---------------------------------------------
    The Pages Features Area of the Page
    ------------------------------------------------>
    <section id="page-articles" class="clear">
    <h1>Bookings Available Now</h1>
	<?php
        if(isset($_POST["check"])) {
            
			$nationalID = $_POST["nationalID"];
			$surname = $_POST["surname"];
			
			$sql = "SELECT * FROM bookings WHERE nationalID = '$nationalID' AND surname = '$surname' ";
			$result = $connect->query($sql);
			?>
			
			

			<?php
			
			if ($result->num_rows > 0) {
			
			
				// output data of each row
				while($row = $result->fetch_assoc()) {
				echo "<p>Your reservation From: <strong>" . $row['fly_from'] . "</strong> To: <strong>" . $row['fly_to'] . "</strong> was processed successfully.</p>";	
			?>	
			
			<strong>Ticket Number </strong><?php echo $row["ticketNO"]; ?><br>	
			<strong>National ID </strong><?php echo $row["nationalID"]; ?><br>
			<strong>Name </strong><?php echo $row["firstname"]; ?> </strong><?php echo $row["surname"]; ?><br>
			<strong>Date of Travel </strong><?php echo $row["day"]. " ".$row["dat"] . " ".$row["month"] . " " .$row["year"]; ?><br>
				
				
			<?php	}
			
			} else {
				
			echo "<br><h3>Nothing Found</h3>" . "<p>No results found on that National ID. Please enter a valid national identification number. </p>";
			echo "<p>Please re-book your reservation again. </p><a href='booking.php'>Bookings Here</a>";
			}
        }
    ?>
    </section>
            
            
            
<!-- Includes the footer section of the website -------------------------------------------------------------------------------------------->
<?php include("includes/footer.php"); ?>



    

