-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2017 at 11:07 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leroynedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `ticketNO` varchar(11) NOT NULL,
  `payment` varchar(30) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `dateofbirth` date NOT NULL,
  `nationalID` varchar(20) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `home_address` text NOT NULL,
  `fly_from` varchar(30) NOT NULL,
  `fly_to` varchar(30) NOT NULL,
  `day` varchar(30) NOT NULL,
  `dat` int(2) NOT NULL,
  `month` varchar(20) NOT NULL,
  `year` int(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `ticketNO`, `payment`, `firstname`, `surname`, `sex`, `dateofbirth`, `nationalID`, `mobile`, `email`, `home_address`, `fly_from`, `fly_to`, `day`, `dat`, `month`, `year`, `date`) VALUES
(1, 'AA84267', '$150.00', 'Tinashe', 'Nechibvute', 'Male', '1987-09-13', '63-1305524E86', '+263-773817112', 'tleroyn@gmail.com', '16257 Damofalls, Ruwa', 'Harare', 'Harare', 'Sunday', 1, 'January', 2017, '2017-03-24 04:12:55'),
(2, 'AA22296', '$100.00', 'Rumbidzai', 'Nechibvute', 'Male', '1994-06-23', '63-1305524E87', '+263-773817110', 'rumbi@me.com', '16257 Damofalls, Ruwa', 'Harare', 'Harare', 'Sunday', 1, 'January', 2017, '2017-03-24 04:04:41'),
(3, 'AA47578', 'None', 'Rumbidzai', 'Nechibvute', 'Female', '1994-06-23', '63-1305524E87', '+263-773817112', 'rumbi@me.com', '1624563\r\nkuwadzana', 'Bulawayo', 'Vicfalls', 'Tuesday', 8, 'August', 2017, '2017-03-24 09:39:30');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `surname`, `mobile`, `email`, `subject`, `message`, `date`) VALUES
(1, 'Tinashe', 'Nechibvute', '0773817112', 'tleroyn@gmail.com', 'Check if working ', 'This is a test', '2017-03-18'),
(2, 'Rumbi', 'Nechibvute', '0772910011', 'love@me.com', 'help', 'help', '2017-03-18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(99) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `date_created`) VALUES
(1, 'leroyne', 'leroyne', 'tleroyn@gmail.com', '2017-03-21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
