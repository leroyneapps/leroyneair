<?php
    
    // The function to post a contact into the database
    
    function contact(){
        
        global $connect;
        
        if(isset($_POST['send'])){
            
        $name = $_POST["name"];
        $surname = $_POST["surname"];
        $email = $_POST["email"];
        $mobile = $_POST["mobile"];
        $subject = $_POST["subject"];
        $message = $_POST["message"];
        
        $insert = " INSERT INTO contacts (id, name, surname, mobile, email,subject, message, date) VALUES ('', '$name', '$surname', '$mobile', '$email','$subject', '$message', now())";
        $query = $connect->query($insert);
        
        
            if($query === true){
                header("Location: index.php");
                
            } else {
                $error = "Failed.";
            }
        }
    }
    
    
    // The function to post a bookings into the database
    
    function booking(){
        
        global $connect;
        
        if(isset($_POST['submit'])){
            
        $firstname = $_POST["firstname"];
        $surname = $_POST["surname"];
        $sex = $_POST["sex"];
        $dateofbirth = $_POST["dateofbirth"];
        $nationalID = $_POST["nationalID"];
        $mobile = $_POST["mobile"];
        $email = $_POST["email"];
        $home_address = $_POST["home_address"];
        $fly_from = $_POST["fly_from"];
        $fly_to = $_POST["fly_to"];
        $day = $_POST["day"];
        $dat = $_POST["dat"];
        $month = $_POST["month"];
        $year = $_POST["year"];
        $ticketNO = "AA".rand(10000, 99999);
        $payment = "None";
        
        
        $insert = " INSERT INTO bookings (id,ticketNO, payment,firstname, surname, sex,dateofbirth, nationalID, mobile, email, home_address, fly_from, fly_to, day, dat, month, year, date) VALUES ('','$ticketNO', '$payment', '$firstname', '$surname', '$sex','$dateofbirth', '$nationalID' ,'$mobile', '$email', '$home_address', '$fly_from' , '$fly_to' , '$day', '$dat', '$month', '$year', now())";
        $query = $connect->query($insert);
        
        
            if($query === true){
                header("Location: index.php");
                
            } else {
                $error = "Failed to insert details.";
                echo $error;
            }
        }
    }
    
    
?>